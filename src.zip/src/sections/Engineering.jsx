export default function Engineering() {
  return (
    <section id="engineering" className="engineering">
      <div className="eng-left">
        <img src="codeslam-frontend\src\assets\engineering.jpg" alt="engine" />
      </div>
      <div className="eng-right">
        <h2>ENGINEERING</h2>
        <p>Precision machining & product optimization.</p>
      </div>
    </section>
  );
}
