export default function Prototyping() {
  return (
    <section id="prototyping" className="proto">
      <div className="proto-left">
        <h2>DESIGN & <span>PROTOTYPING</span></h2>
        <p>High‑fidelity prototypes ready for field testing.</p>
      </div>
      <div className="proto-right">
        <img src="/assets/axe.png" alt="axe" />
      </div>
    </section>
  );
}
