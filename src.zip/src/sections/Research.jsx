export default function Research() {
  return (
    <section id="research" className="research">
      <div className="research-left">
        <img src="/assets/machine.png" alt="machine" />
      </div>
      <div className="research-right">
        <h2>RESEARCH & <span>DEVELOPMENT</span></h2>
        <p>Advanced experimentation & innovation.</p>
      </div>
    </section>
  );
}
